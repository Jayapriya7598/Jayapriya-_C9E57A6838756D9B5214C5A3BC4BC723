Y=int(input("Enther the year:"))
if(y%4==0):
  print("loop year")
else:
  print("Not a loop year")