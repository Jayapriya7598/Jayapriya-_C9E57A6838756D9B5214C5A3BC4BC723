#define the base class player 
class Player:
     def Play(self):
         print("the player is playing cricket.")
       
#define the derived  class Batsman
class Batsman(Player):
     def Play(self):
         print("the batsman is batting.")
       
#define the derived class Bowler 
class Bowler(Player):
     def Play(self):
         print("the bowler is bowling.")
#create object of Batsman is Bowler classes

batsman = Batsman()
bowler = Bowler()

#call the play() method of each object 
batsman.Play()
bowler.Play()
